<!-- This file is used to store sidebar items, starting with Backpack\Base 0.9.0 -->



    
    
        
        
    


<li><a href='<?php echo e('/'); ?>'><i class='fa fa-tag'></i> <span>Home</span></a></li>
<li><a href='<?php echo e('/search'); ?>'><i class='fa fa-tag'></i> <span>Search</span></a></li>
<li><a href='<?php echo e('/book'); ?>'><i class='fa fa-tag'></i> <span>Books</span></a></li>